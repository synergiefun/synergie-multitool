@echo off
chcp 65001 >nul
title SYNERGIE MULTITOOL V1 - Installation et compilation
color 0B
cd /d "%~dp0"

echo.
echo  ================================================
echo          SYNERGIE MULTITOOL V1
echo          INSTALLATION + CREATION DU .EXE
echo  ================================================
echo.

where py >nul 2>&1
if errorlevel 1 (
    echo [ERREUR] Python n'est pas installe ou son lanceur "py" est absent.
    echo Installe Python 3.10 ou plus recent depuis :
    echo https://www.python.org/downloads/
    echo Pendant l'installation, coche "Add Python to PATH".
    echo Relance ensuite INSTALLER.bat.
    pause
    exit /b 1
)

echo [1/4] Mise a jour de pip...
py -m pip install --upgrade pip
if errorlevel 1 goto error

echo.
echo [2/4] Installation des dependances...
py -m pip install -r requirements.txt
if errorlevel 1 goto error

echo.
echo [3/4] Nettoyage de l'ancienne compilation...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist "Synergie MultiTool V1.spec" del /q "Synergie MultiTool V1.spec"

echo.
echo [4/4] Creation de Synergie MultiTool V1.exe...
py -m PyInstaller --noconfirm --clean --onefile --console --name "Synergie MultiTool V1" --icon "SynergieLogo.ico" "Synergie_MultiTool_V1.py"
if errorlevel 1 goto error

echo.
echo  ================================================
echo       COMPILATION TERMINEE AVEC SUCCES !
echo  ================================================
echo.
echo Ton executable se trouve ici :
echo %~dp0dist\Synergie MultiTool V1.exe
echo.
echo Tu peux copier le fichier .exe sur ton Bureau.
echo Le dossier Synergie_Reports sera cree a cote du .exe
echo au premier lancement, selon le dossier courant.
echo.
start "" "%~dp0dist"
pause
exit /b 0

:error
echo.
echo [ERREUR] Une etape a echoue.
echo Verifie ta connexion Internet et que Python est correctement installe.
pause
exit /b 1
