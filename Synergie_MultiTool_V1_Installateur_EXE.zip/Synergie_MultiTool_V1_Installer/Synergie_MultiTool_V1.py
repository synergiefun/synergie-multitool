# -*- coding: utf-8 -*-
"""
SYNERGIE MULTITOOL V1
Outil de diagnostic PC et OSINT public, pour Windows 10/11.
Utilisation responsable : uniquement vos appareils, domaines et services autorisés.
Python 3.10+ ; dépendances facultatives : psutil, phonenumbers
"""

import os
import sys
import re
import json
import ssl
import socket
import shutil
import hashlib
import platform
import subprocess
import webbrowser
import urllib.request
import urllib.parse
import ipaddress
from pathlib import Path
from datetime import datetime

APP_NAME = "SYNERGIE MULTITOOL"
VERSION = "V1.0"
REPORT_DIR = Path("Synergie_Reports")
REPORT_DIR.mkdir(exist_ok=True)

# ---------- Couleurs terminal ----------
class C:
    RESET = "\033[0m"
    GREEN = "\033[92m"
    CYAN = "\033[96m"
    RED = "\033[91m"
    YELLOW = "\033[93m"
    WHITE = "\033[97m"
    GREY = "\033[90m"
    BOLD = "\033[1m"

def enable_colors():
    if os.name == "nt":
        os.system("")

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def line(char="─", size=66):
    print(C.GREY + char * size + C.RESET)

def title(text):
    line()
    print(C.CYAN + C.BOLD + f"  {text}" + C.RESET)
    line()

def ok(text): print(C.GREEN + "[+] " + text + C.RESET)
def info(text): print(C.CYAN + "[i] " + text + C.RESET)
def warn(text): print(C.YELLOW + "[!] " + text + C.RESET)
def err(text): print(C.RED + "[-] " + text + C.RESET)

def pause():
    input("\nAppuie sur Entrée pour continuer...")

def ask(prompt):
    return input(C.YELLOW + prompt + C.RESET).strip()

def run_command(args, timeout=15):
    try:
        result = subprocess.run(args, capture_output=True, text=True,
                                errors="replace", timeout=timeout, shell=False)
        output = (result.stdout or "") + (result.stderr or "")
        return output.strip() or f"Aucune sortie (code {result.returncode})."
    except FileNotFoundError:
        return "Commande indisponible sur ce système."
    except subprocess.TimeoutExpired:
        return "Délai dépassé."
    except Exception as e:
        return f"Erreur : {e}"

def http_get(url, timeout=10, headers=None):
    req = urllib.request.Request(
        url,
        headers=headers or {"User-Agent": "SynergieMultiTool/1.0 (public information lookup)"}
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        data = response.read(1_500_000)
        charset = response.headers.get_content_charset() or "utf-8"
        return response.status, response.headers, data.decode(charset, errors="replace")

def save_report(name, data):
    safe = re.sub(r"[^A-Za-z0-9_-]", "_", name)[:40] or "rapport"
    path = REPORT_DIR / f"{safe}_{datetime.now():%Y%m%d_%H%M%S}.json"
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, default=str)
    ok(f"Rapport enregistré : {path.resolve()}")

def normalize_domain(value):
    value = value.strip().lower()
    value = re.sub(r"^https?://", "", value)
    value = value.split("/")[0].split(":")[0]
    if not value or " " in value:
        raise ValueError("Nom de domaine invalide.")
    return value

def normalize_url(value):
    value = value.strip()
    if not value.startswith(("http://", "https://")):
        value = "https://" + value
    parsed = urllib.parse.urlparse(value)
    if not parsed.hostname:
        raise ValueError("URL invalide.")
    return value

def show_output(text):
    print()
    print(text)
    print()

# ---------- 1 à 7 : système ----------
def pc_summary():
    title("01 - INFORMATIONS PC")
    data = {
        "Machine": platform.node(),
        "Système": platform.platform(),
        "Version": platform.version(),
        "Architecture": platform.machine(),
        "Processeur": platform.processor(),
        "Python": sys.version.split()[0],
    }
    try:
        import psutil
        data["RAM totale (Go)"] = round(psutil.virtual_memory().total / 1024**3, 2)
        data["RAM utilisée (%)"] = psutil.virtual_memory().percent
        data["CPU utilisé (%)"] = psutil.cpu_percent(interval=1)
        data["Disque système (Go)"] = round(psutil.disk_usage(os.environ.get("SystemDrive", "C:") + "\\").total / 1024**3, 2)
    except ImportError:
        info("Installe psutil pour obtenir les mesures RAM/CPU/disque : pip install psutil")
    for k, v in data.items(): print(f"{C.CYAN}{k:<23}{C.WHITE}: {v}{C.RESET}")
    save_report("pc_summary", data)

def running_processes():
    title("02 - PROCESSUS EN COURS")
    try:
        import psutil
        rows = sorted(
            [(p.info["pid"], p.info["name"] or "?", p.info.get("memory_info").rss // 1024**2 if p.info.get("memory_info") else 0)
             for p in psutil.process_iter(["pid", "name", "memory_info"])],
            key=lambda x: x[2], reverse=True
        )
        for pid, name, mem in rows[:35]:
            print(f"{pid:>7}  {name[:36]:<36} {mem:>5} Mo")
        info("Affichage limité aux 35 processus utilisant le plus de mémoire.")
    except ImportError:
        show_output(run_command(["tasklist"]))
        warn("Installe psutil pour un affichage trié.")

def storage_info():
    title("03 - STOCKAGE")
    try:
        import psutil
        for part in psutil.disk_partitions():
            try:
                u = psutil.disk_usage(part.mountpoint)
                print(f"{part.device} | {u.total/1e9:.1f} Go total | {u.used/1e9:.1f} Go utilisés | {u.percent}%")
            except PermissionError:
                pass
    except ImportError:
        show_output(run_command(["wmic", "logicaldisk", "get", "caption,size,freespace"]))

def battery_info():
    title("04 - BATTERIE")
    if os.name == "nt":
        show_output(run_command(["powercfg", "/batteryreport", "/output", str((Path.cwd() / "battery-report.html").resolve())]))
        info("Si le rapport a été créé, ouvre battery-report.html dans le dossier du programme.")
    else:
        try:
            import psutil
            b = psutil.sensors_battery()
            show_output(str(b) if b else "Aucune batterie détectée.")
        except ImportError:
            warn("Fonction disponible avec psutil : pip install psutil")

def startup_apps():
    title("05 - APPLICATIONS AU DÉMARRAGE")
    if os.name == "nt":
        show_output(run_command(["powershell", "-NoProfile", "-Command",
            "Get-CimInstance Win32_StartupCommand | Select-Object Name,Command,Location | Format-Table -AutoSize"]))
    else:
        show_output("Fonction conçue pour Windows.")

def windows_security():
    title("06 - ÉTAT DE SÉCURITÉ WINDOWS")
    if os.name == "nt":
        commands = [
            ["powershell", "-NoProfile", "-Command",
             "Get-MpComputerStatus | Select-Object AntivirusEnabled,RealTimeProtectionEnabled,AntivirusSignatureLastUpdated | Format-List"],
            ["powershell", "-NoProfile", "-Command",
             "Get-NetFirewallProfile | Select-Object Name,Enabled | Format-Table -AutoSize"]
        ]
        for cmd in commands:
            show_output(run_command(cmd))
    else:
        warn("Cette fonction nécessite Windows Defender.")

def environment_info():
    title("07 - VARIABLES ET VERSION")
    data = {"OS": os.name, "Python": sys.version, "Répertoire": str(Path.cwd()),
            "Utilisateur local": os.environ.get("USERNAME", os.environ.get("USER", "inconnu"))}
    for k, v in data.items(): print(f"{k}: {v}")
    save_report("environment", data)

# ---------- 8 à 14 : réseau ----------
def local_ip():
    title("08 - ADRESSES IP LOCALES")
    show_output(run_command(["ipconfig", "/all"]) if os.name == "nt" else run_command(["ip", "addr"]))

def public_ip():
    title("09 - ADRESSE IP PUBLIQUE")
    try:
        _, _, body = http_get("https://api.ipify.org?format=json")
        data = json.loads(body)
        ok("IP publique : " + data.get("ip", "inconnue"))
        warn("Une adresse IP peut être une donnée personnelle. Ne la publie pas.")
    except Exception as e:
        err(f"Recherche impossible : {e}")

def dns_lookup():
    title("10 - RECHERCHE DNS")
    domain = normalize_domain(ask("Domaine à vérifier : "))
    records = {}
    for kind in ("A", "AAAA", "MX", "NS", "TXT"):
        try:
            import dns.resolver
            answers = dns.resolver.resolve(domain, kind, lifetime=4)
            records[kind] = [str(r) for r in answers]
        except ImportError:
            records["Info"] = ["Installe dnspython : pip install dnspython"]
            break
        except Exception:
            records[kind] = []
    for k, vals in records.items():
        print(f"\n{k}:")
        for val in vals: print("  " + val)
    save_report("dns_" + domain, records)

def ping_host():
    title("11 - TEST DE CONNEXION PING")
    host = ask("Hôte ou domaine (autorisé) : ")
    if not re.fullmatch(r"[A-Za-z0-9.:-]+", host):
        err("Entrée invalide."); return
    cmd = ["ping", "-n", "4", host] if os.name == "nt" else ["ping", "-c", "4", host]
    show_output(run_command(cmd, timeout=12))

def traceroute_host():
    title("12 - ROUTE RÉSEAU")
    host = ask("Hôte ou domaine (autorisé) : ")
    if not re.fullmatch(r"[A-Za-z0-9.:-]+", host):
        err("Entrée invalide."); return
    cmd = ["tracert", "-d", host] if os.name == "nt" else ["traceroute", "-n", host]
    show_output(run_command(cmd, timeout=25))

def port_check():
    title("13 - TEST D'UN PORT UNIQUE")
    warn("À utiliser uniquement sur un serveur qui t'appartient ou pour lequel tu as une autorisation.")
    host = ask("Nom/IP du serveur autorisé : ")
    try:
        port = int(ask("Port unique à tester (1-65535) : "))
        if not (1 <= port <= 65535): raise ValueError()
        with socket.create_connection((host, port), timeout=3):
            ok(f"Le port {port} répond sur {host}.")
    except ValueError:
        err("Port invalide.")
    except OSError as e:
        info(f"Connexion non établie : {e}")

def network_adapters():
    title("14 - CARTES RÉSEAU")
    if os.name == "nt":
        show_output(run_command(["ipconfig", "/all"]))
    else:
        show_output(run_command(["ip", "link"]))

# ---------- 15 à 23 : OSINT public ----------
def ip_info():
    title("15 - INFORMATIONS PUBLIQUES SUR UNE IP")
    raw = ask("Adresse IP publique : ")
    try:
        ip = ipaddress.ip_address(raw)
        if not ip.is_global:
            warn("Cette adresse n'est pas une IP publique globale."); return
        _, _, body = http_get("https://ipwho.is/" + urllib.parse.quote(str(ip)))
        data = json.loads(body)
        if not data.get("success", True):
            err("Service de géolocalisation indisponible."); return
        fields = ("ip", "type", "continent", "country", "region", "city", "connection", "timezone")
        result = {k: data.get(k) for k in fields}
        show_output(json.dumps(result, indent=2, ensure_ascii=False))
        save_report("ip_public_info", result)
        warn("La localisation IP est approximative et ne révèle pas une adresse personnelle exacte.")
    except Exception as e:
        err(f"Erreur : {e}")

def domain_rdap():
    title("16 - INFORMATIONS PUBLIQUES DOMAINE (RDAP)")
    domain = normalize_domain(ask("Domaine : "))
    try:
        _, _, body = http_get("https://rdap.org/domain/" + urllib.parse.quote(domain))
        data = json.loads(body)
        result = {"domain": data.get("ldhName"), "status": data.get("status"),
                  "events": data.get("events"), "nameservers": data.get("nameservers")}
        show_output(json.dumps(result, indent=2, ensure_ascii=False))
        save_report("rdap_" + domain, result)
    except Exception as e:
        err(f"RDAP indisponible : {e}")

def website_headers():
    title("17 - EN-TÊTES HTTP D'UN SITE")
    url = normalize_url(ask("URL du site : "))
    try:
        req = urllib.request.Request(url, method="HEAD",
            headers={"User-Agent": "SynergieMultiTool/1.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = {"url": url, "status": r.status, "headers": dict(r.headers.items())}
        show_output(json.dumps(data, indent=2, ensure_ascii=False))
        save_report("http_headers", data)
    except Exception as e:
        err(f"Impossible de lire les en-têtes : {e}")

def ssl_check():
    title("18 - CERTIFICAT HTTPS")
    domain = normalize_domain(ask("Domaine : "))
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=5) as sock:
            with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
        data = {"domaine": domain, "version_tls": ssock.version(),
                "émetteur": cert.get("issuer"), "valide_du": cert.get("notBefore"),
                "valide_jusqu'au": cert.get("notAfter")}
        show_output(json.dumps(data, indent=2, ensure_ascii=False))
        save_report("ssl_" + domain, data)
    except Exception as e:
        err(f"Vérification impossible : {e}")

def robots_sitemap():
    title("19 - FICHIERS PUBLICS ROBOTS.TXT / SITEMAP")
    url = normalize_url(ask("Site web : "))
    base = urllib.parse.urlparse(url)
    root = f"{base.scheme}://{base.netloc}"
    for path in ("/robots.txt", "/sitemap.xml"):
        print(f"\n{C.CYAN}{path}{C.RESET}")
        try:
            _, _, body = http_get(root + path)
            print(body[:5000])
        except Exception as e:
            info(str(e))

def username_search():
    title("20 - RECHERCHE PUBLIQUE DE PSEUDO")
    username = ask("Pseudo à rechercher : ")
    if not re.fullmatch(r"[A-Za-z0-9_.-]{2,32}", username):
        err("Pseudo invalide (2 à 32 caractères)."); return
    sites = [
        ("GitHub", f"https://github.com/{username}"),
        ("Reddit", f"https://www.reddit.com/user/{username}/"),
        ("Twitch", f"https://www.twitch.tv/{username}"),
        ("YouTube", f"https://www.youtube.com/@{username}"),
        ("TikTok", f"https://www.tiktok.com/@{username}"),
        ("Instagram", f"https://www.instagram.com/{username}/"),
    ]
    print("Liens publics à vérifier manuellement :")
    for name, url in sites:
        print(f"{name:<12} {url}")
    if ask("Ouvrir ces liens dans le navigateur ? (o/n) : ").lower() == "o":
        for _, url in sites: webbrowser.open_new_tab(url)

def email_search():
    title("21 - RECHERCHE WEB D'UNE ADRESSE E-MAIL")
    email = ask("Adresse e-mail : ")
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        err("Format d'e-mail invalide."); return
    query = urllib.parse.quote('"' + email + '"')
    url = "https://www.google.com/search?q=" + query
    info("Cette option ouvre une recherche web publique, sans accéder à une boîte mail.")
    webbrowser.open(url)

def phone_info():
    title("22 - FORMAT ET VALIDATION D'UN NUMÉRO")
    number = ask("Numéro avec indicatif (ex. +33...) : ")
    try:
        import phonenumbers
        parsed = phonenumbers.parse(number, None)
        data = {"valide": phonenumbers.is_valid_number(parsed),
                "possible": phonenumbers.is_possible_number(parsed),
                "format_international": phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
                "pays": phonenumbers.region_code_for_number(parsed)}
        show_output(json.dumps(data, indent=2, ensure_ascii=False))
    except ImportError:
        warn("Installe la dépendance : pip install phonenumbers")
    except Exception as e:
        err(f"Numéro non reconnu : {e}")

def web_search():
    title("23 - RECHERCHE WEB MULTI-MOTEURS")
    query = ask("Recherche : ")
    if not query: return
    q = urllib.parse.quote(query)
    urls = [
        "https://www.google.com/search?q=" + q,
        "https://www.bing.com/search?q=" + q,
        "https://duckduckgo.com/?q=" + q,
    ]
    for u in urls: print(u)
    if ask("Ouvrir les trois moteurs ? (o/n) : ").lower() == "o":
        for u in urls: webbrowser.open_new_tab(u)

# ---------- 24 à 27 : fichiers ----------
def file_hash():
    title("24 - CALCUL HASH SHA-256")
    path = Path(ask("Chemin du fichier : ").strip('"'))
    if not path.is_file():
        err("Fichier introuvable."); return
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    ok("SHA-256 : " + h.hexdigest())

def file_metadata():
    title("25 - MÉTADONNÉES D'UN FICHIER")
    path = Path(ask("Chemin du fichier : ").strip('"'))
    if not path.is_file():
        err("Fichier introuvable."); return
    st = path.stat()
    data = {"nom": path.name, "extension": path.suffix, "taille_octets": st.st_size,
            "création_epoch": st.st_ctime, "modification_epoch": st.st_mtime}
    show_output(json.dumps(data, indent=2, ensure_ascii=False))
    save_report("file_metadata", data)

def defender_scan():
    title("26 - ANALYSE MICROSOFT DEFENDER")
    path = Path(ask("Fichier ou dossier à analyser : ").strip('"'))
    if not path.exists():
        err("Chemin introuvable."); return
    if os.name != "nt":
        warn("Microsoft Defender est disponible sur Windows."); return
    cmd = ["powershell", "-NoProfile", "-Command",
           "Start-MpScan -ScanType CustomScan -ScanPath " + "'" + str(path).replace("'", "''") + "'"]
    warn("L'analyse peut prendre du temps.")
    show_output(run_command(cmd, timeout=180))

def list_folder():
    title("27 - EXPLORATEUR DE FICHIERS TEXTE")
    folder = Path(ask("Dossier à lister : ").strip('"'))
    if not folder.is_dir():
        err("Dossier introuvable."); return
    for p in sorted(folder.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))[:100]:
        kind = "[DOSSIER]" if p.is_dir() else "[FICHIER]"
        print(f"{kind:<10} {p.name}")
    info("Affichage limité à 100 éléments.")

# ---------- 28 à 30 : outils ----------
def json_viewer():
    title("28 - LECTEUR JSON")
    path = Path(ask("Chemin du fichier JSON : ").strip('"'))
    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        show_output(json.dumps(data, indent=2, ensure_ascii=False)[:12000])
    except Exception as e:
        err(f"Lecture impossible : {e}")

def password_generator():
    title("29 - GÉNÉRATEUR DE MOT DE PASSE")
    import secrets, string
    try:
        length = int(ask("Longueur (12 à 64) : "))
        if not 12 <= length <= 64: raise ValueError()
    except ValueError:
        err("Choisis une longueur entre 12 et 64."); return
    alphabet = string.ascii_letters + string.digits + "!@#$%&*+-_?"
    password = "".join(secrets.choice(alphabet) for _ in range(length))
    print(C.GREEN + C.BOLD + password + C.RESET)
    info("Garde ce mot de passe dans un gestionnaire sécurisé. Ne le partage pas.")

def export_report():
    title("30 - EXPORT / DOSSIER DES RAPPORTS")
    files = sorted(REPORT_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not files:
        info("Aucun rapport enregistré pour le moment."); return
    for f in files[:30]:
        print(f"{f.name:<48} {f.stat().st_size:>8} octets")
    info(f"Dossier : {REPORT_DIR.resolve()}")

# ---------- Menus ----------
MODULES = {
    "SYSTEME": [
        ("01", "Informations PC", pc_summary),
        ("02", "Processus en cours", running_processes),
        ("03", "Stockage", storage_info),
        ("04", "Batterie", battery_info),
        ("05", "Applications au démarrage", startup_apps),
        ("06", "Sécurité Windows / Defender", windows_security),
        ("07", "Variables et version", environment_info),
    ],
    "RESEAU": [
        ("08", "Adresses IP locales", local_ip),
        ("09", "Adresse IP publique", public_ip),
        ("10", "Recherche DNS", dns_lookup),
        ("11", "Test Ping", ping_host),
        ("12", "Traceroute", traceroute_host),
        ("13", "Test d'un port unique (autorisé)", port_check),
        ("14", "Cartes réseau", network_adapters),
    ],
    "OSINT PUBLIC": [
        ("15", "Informations publiques sur une IP", ip_info),
        ("16", "Informations domaine (RDAP)", domain_rdap),
        ("17", "En-têtes HTTP", website_headers),
        ("18", "Certificat HTTPS", ssl_check),
        ("19", "Robots.txt / Sitemap", robots_sitemap),
        ("20", "Recherche publique de pseudo", username_search),
        ("21", "Recherche web d'un e-mail", email_search),
        ("22", "Validation numéro de téléphone", phone_info),
        ("23", "Recherche web multi-moteurs", web_search),
    ],
    "FICHIERS": [
        ("24", "Calcul SHA-256", file_hash),
        ("25", "Métadonnées fichier", file_metadata),
        ("26", "Analyse Microsoft Defender", defender_scan),
        ("27", "Lister un dossier", list_folder),
    ],
    "UTILITAIRES": [
        ("28", "Lecteur JSON", json_viewer),
        ("29", "Générateur de mot de passe", password_generator),
        ("30", "Exporter / consulter les rapports", export_report),
    ],
}

def banner():
    clear()
    print(C.GREEN + C.BOLD)
    print(r"""
   _____ __   __ _   _ _____ ____   ____ ___ _____
  / ____|\ \ / /| \ | | ____|  _ \ / ___|_ _| ____|
  \___ \  \ V / |  \| |  _| | |_) | |    | ||  _|
   ___) |  | |  | |\  | |___|  _ <| |___ | || |___
  |____/   |_|  |_| \_|_____|_| \_\\____|___|_____|
""")
    print(C.CYAN + f"                 MULTITOOL {VERSION}" + C.RESET)
    print(C.GREY + "          PC DIAGNOSTIC  |  NETWORK  |  PUBLIC OSINT" + C.RESET)
    line()

def category_menu(category, items):
    while True:
        banner()
        title(category)
        for number, label, _ in items:
            print(f"  {C.GREEN}{number}{C.RESET}  {label}")
        print(f"\n  {C.RED}0{C.RESET}  Retour")
        choice = ask("\nSynergie > ")
        if choice == "0": return
        selected = next((fn for n, _, fn in items if n == choice), None)
        if selected:
            try: selected()
            except KeyboardInterrupt: warn("Opération interrompue.")
            except Exception as e: err(f"Erreur inattendue : {e}")
            pause()
        else:
            warn("Option inconnue.")
            pause()

def main():
    enable_colors()
    while True:
        banner()
        print(f"  {C.WHITE}Bienvenue dans {APP_NAME}{C.RESET}\n")
        for i, (category, items) in enumerate(MODULES.items(), 1):
            print(f"  {C.CYAN}{i}{C.RESET}  {category:<16} {C.GREY}({len(items)} modules){C.RESET}")
        print(f"\n  {C.YELLOW}A{C.RESET}  Afficher les 30 options")
        print(f"  {C.RED}0{C.RESET}  Quitter")
        choice = ask("\nSynergie > ").lower()
        if choice == "0":
            print(C.GREEN + "\nMerci d'avoir utilisé Synergie MultiTool !" + C.RESET)
            break
        if choice == "a":
            banner()
            title("LES 30 FONCTIONNALITÉS")
            for category, items in MODULES.items():
                print(f"\n{C.CYAN}{category}{C.RESET}")
                for n, label, _ in items: print(f"  {n} - {label}")
            pause()
            continue
        try:
            index = int(choice) - 1
            category = list(MODULES.keys())[index]
            category_menu(category, MODULES[category])
        except (ValueError, IndexError):
            warn("Choisis une catégorie valide.")
            pause()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nFermeture de Synergie MultiTool.")
